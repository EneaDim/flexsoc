// Timescale 
`timescale 1ns/1ps 
// Include files 
`include "include_fft_fsm_tb.sv"

module fft_fsm_tb;
  //Parameters
  parameter int CLK_PERIOD = 10; // Clock period in ns
  // Inputs
  reg clk_i;
  reg rst_ni;
  reg start_i;
  reg end_samples_i;
  reg end_read_1;
  reg end_read_2;
  reg end_compute_i;
  reg end_write_1;
  reg end_algo_i;
  // Outputs
  wire en_cnt_samples_o;
  wire wr_mem_o;
  wire en_cnt_rd_o;
  wire done_o;
  state_fsm state_o;

  integer error_count;


  // Device Under Test Instance
  fft_fsm
  u_fft_fsm (
    .clk_i,
    .rst_ni,
    .start_i,
    .end_samples_i,
    .end_read_1,
    .end_read_2,
    .end_compute_i,
    .end_write_1,
    .end_algo_i,
    .en_cnt_samples_o,
    .wr_mem_o,
    .en_cnt_rd_o,
    .done_o,
    .state_o
  );

  // Clock generation
  initial begin
    clk_i = 0;
    forever #(CLK_PERIOD / 2) clk_i = ~clk_i;
  end

  // Dump VCD
  string vcd_path;
  initial begin
    if (!$value$plusargs("VCD=%s", vcd_path)) begin
      `ifndef SYN
        vcd_path = "";
      `else
        vcd_path = "";
      `endif
    end
    $display("[TB] dumpfile = %s", vcd_path);
    $dumpfile(vcd_path);
    $dumpvars(0, gpio_tb);
  end

  // SDF backannotation
  `ifndef VERILATOR
    string sdf_path;
    initial begin
      if (!$value$plusargs("SDF=%s", sdf_path)) begin
        sdf_path = "";
      end
      $display("[TB] sdf = %s", sdf_path);
      $sdf_annotate(sdf_path, gpio_tb.u_gpio, , , "MAXIMUM");
    end
  `endif

  // Error count
  initial begin
    error_count = 0;
  end

  initial begin
    // Init inputs
    rst_ni = 0;
    start_i = 0;
    end_samples_i = 0;
    end_read_1 = 0;
    end_read_2 = 0;
    end_compute_i = 0;
    end_write_1 = 0;
    end_algo_i = 0;
    // Asynch Reset
    #(CLK_PERIOD);
    rst_ni = 1;
    #(CLK_PERIOD);
    // Start main test
    $display("\nRunning...\n");
    // INSERT YOUR CODE


    // Final Check
    if (error_count == 0) begin
      $display("Coverage: 100%%");
    end
    $display("\nEnd.\n");
    $finish;
  end
endmodule
