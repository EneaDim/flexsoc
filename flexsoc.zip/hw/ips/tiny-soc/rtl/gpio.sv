// Copyright lowRISC contributors (OpenTitan project).
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0
//
// General Purpose Input/Output module

`include "prim_assert.sv"

module gpio
  import gpio_reg_pkg::*;
#(
  // This parameter instantiates 2-stage synchronizers on all GPIO inputs.
  parameter bit GpioAsyncOn = 1
) (
  input clk_i,
  input rst_ni,

  // Bus interface
  input  tlul_pkg::tl_h2d_t tl_i,
  output tlul_pkg::tl_d2h_t tl_o,

  // Interrupts
  output logic [1:0] intr_gpio_o,

  // GPIOs
  input        [1:0] cio_gpio_i,
  output logic [1:0] cio_gpio_o,
  output logic [1:0] cio_gpio_en_o
);



  gpio_reg2hw_t reg2hw;
  gpio_hw2reg_t hw2reg;

  logic [1:0] cio_gpio_q;
  logic [1:0] cio_gpio_en_q;

  // possibly filter the input based upon register configuration
  logic [1:0] data_in_d;
  localparam int unsigned CntWidth = 2;
  for (genvar i = 0 ; i < 2 ; i++) begin : gen_filter
    prim_filter_ctr #(
      .AsyncOn(GpioAsyncOn),
      .CntWidth(CntWidth)
    ) u_filter (
      .clk_i,
      .rst_ni,
      .enable_i(reg2hw.ctrl_en_input_filter.q[i]),
      .filter_i(cio_gpio_i[i]),
      .thresh_i({CntWidth{1'b1}}),
      .filter_o(data_in_d[i])
    );
  end

  // GPIO_IN
  assign hw2reg.data_in.de = 1'b1;
  assign hw2reg.data_in.d  = data_in_d;

  // GPIO_OUT
  assign cio_gpio_o                     = cio_gpio_q;
  assign cio_gpio_en_o                  = cio_gpio_en_q;

  assign hw2reg.direct.gpio_o.d         = cio_gpio_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cio_gpio_q  <= '0;
    end else if (reg2hw.direct.gpio_o.qe) begin
      cio_gpio_q <= reg2hw.direct.gpio_o.q;
    end
  end

  // GPIO OE
  assign hw2reg.direct.gpio_oe.d = cio_gpio_en_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cio_gpio_en_q  <= '0;
    end else if (reg2hw.direct.gpio_oe.qe) begin
      cio_gpio_en_q <= reg2hw.direct.gpio_oe.q;
    end
  end

  logic [1:0] data_in_q;
  always_ff @(posedge clk_i) begin
    data_in_q <= data_in_d;
  end

  logic [1:0] event_intr_rise, event_intr_fall, event_intr_actlow, event_intr_acthigh;

  // detect four possible individual interrupts
  assign event_intr_rise    = (~data_in_q &  data_in_d) & reg2hw.intr_ctrl.en_rising.q;
  assign event_intr_fall    = ( data_in_q & ~data_in_d) & reg2hw.intr_ctrl.en_falling.q;
  assign event_intr_acthigh =                data_in_d  & reg2hw.intr_ctrl.en_lvlhigh.q;
  assign event_intr_actlow  =               ~data_in_d  & reg2hw.intr_ctrl.en_lvllow.q;

  assign intr_gpio_o        =  event_intr_rise   |
                               event_intr_fall   |
                               event_intr_actlow |
                               event_intr_acthigh;

  // Register module
  gpio_reg_top u_reg (
    .clk_i,
    .rst_ni,
    .tl_i,
    .tl_o,
    .reg2hw,
    .hw2reg,
    .devmode_i(1'b1)

  );

  // Assert Known: Outputs
  `ASSERT_KNOWN(IntrGpioKnown, intr_gpio_o)
  `ASSERT_KNOWN(CioGpioEnOKnown, cio_gpio_en_o)
  `ASSERT_KNOWN(CioGpioOKnown, cio_gpio_o)

  // Alert assertions for reg_we onehot check
  `ASSERT_PRIM_REG_WE_ONEHOT_ERROR_TRIGGER_ALERT(RegWeOnehotCheck_A, u_reg, alert_tx_o[0])
endmodule
